package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.Titles;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.exceptions.TitlesNotFoundException;
import com.cg.training.services.TitleServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

@RestController  // Restful controller
@RequestMapping("/api/v1/titles") // base url for apis related to titles
public class TitlesController {
	
	@Autowired // instead of creation of objects using new keyword
    private TitleServiceImpl titleService;
	
	
	/*
	 * Fetch all title objects.
	 */
    @GetMapping("/all") 
    public List<Titles> findAllSalary() {
    	
       
        return titleService.getTitles();
    }

    //Add a new title object to the database.
    
    @PostMapping("/add")
    public ResponseEntity<Titles> addNewTitles(@RequestBody Titles titles) {
    	
        Titles createdTitle = titleService.addTitle(titles);
        if (createdTitle != null) {
            return ResponseEntity.status(HttpStatus.OK).body(createdTitle);
        } else {
            throw new InvalidDataException("Validation Failed");
        }
    }
    
    
     //Fetch titles by employee number, from date, and title.
     
    @GetMapping("/empno/{empno}/fromdate/{fromdate}/title/{title}")
    public List<Titles> findByEmpNoAndFromDateAndTitle(@PathVariable("empno") int empNo,
            @PathVariable("fromdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
            @PathVariable("title") String title) throws TitlesNotFoundException {
    	
        return titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate, title);
    }

    
     //Fetch titles by title. 
     

    @GetMapping("/title/{title}")
    public List<Titles> findAllByTitle(@PathVariable("title") String title) throws TitlesNotFoundException {
    
        return titleService.getAllByTitle(title);
    }

    
       //Fetch titles by from date.
     
    @GetMapping("/fromdate/{fromDate}")
    public List<Titles> findByFromDate(
            @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDateParam) throws TitlesNotFoundException {
    	
        return titleService.findAllByFromDate(fromDateParam);
    }

    
      //Fetch titles by title and from date.
	 
    @GetMapping("title/{title}/fromdate/{fromdate}")
    public List<Titles> findByEmpNoAndFromDateAndTitle(
            @PathVariable("fromdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
            @PathVariable("title") String title) throws TitlesNotFoundException {
    	
        return titleService.getTitleByTitleAndFromDate(fromDate, title);
    }

 
    //Fetch titles by employee number and title.
     
    @GetMapping("/empno/{empno}/title/{title}")
    public List<Titles> findByEmpNoAndAndTitle(@PathVariable("empno") int empNo, @PathVariable("title") String title) throws TitlesNotFoundException {
    	
    	return titleService.getTitleByTitleAndFromDate(empNo, title);
    }

    //Fetch titles by employee number and from date. 
     
    @GetMapping("/empno/{empno}/fromdate/{fromdate}")
    public List<Titles> findByEmpNoAndFromDate(@PathVariable("empno") int empNo,
            @PathVariable("fromdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
    
        return titleService.getTitleByEmpNoAndFromDate(empNo, fromDate);
    }
    
//Update title by employee number, from date, and title.

     

    

    @PutMapping("/empno/{empno}/fromdate/{fromdate}/title/{oldTitle}")

    public ResponseEntity<String> updateTitleByEmpNoAndFromDateAndTitle(

            @PathVariable int empno,

            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromdate,

            @PathVariable String oldTitle,

            @RequestBody String newTitle) {

        try {

            titleService.updateTitleByEmpNoAndFromDateAndTitle(empno, fromdate, oldTitle, newTitle);

            return new ResponseEntity<>("Title updated Successfully",HttpStatus.OK);

        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)

                .body("Internal server error");

        }

    }

	

	// Update title by employee number.

	

    @PutMapping("/{empno}")

    public ResponseEntity<String> updateTitlesByEmpNo(

            @PathVariable int empno,

            @RequestBody String newTitle) {

        try {

            titleService.updateTitlesByEmpNo(empno, newTitle);

            return new ResponseEntity<>("Title details updated successfully",HttpStatus.OK);

        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)

                .body("Internal server error");

        }

    }

	

	 // Update title by from date.

	

    @PutMapping("/fromdate/{fromdate}")

    public ResponseEntity<String> updateTitleByFromDate(

            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromdate,

            @RequestBody String newTitle) {

        try {

            titleService.updateTitleByFromDate(fromdate, newTitle);

            return new ResponseEntity<>("Title details updated successfully",HttpStatus.OK);

        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)

                .body("Internal server error");

        }

    }

	

	//Update title by title.

	

    @PutMapping("/title/{oldTitle}")

    public ResponseEntity<String> updateTitlesByTitle(

            @PathVariable String oldTitle,

            @RequestBody String newTitle) {

        try {

            titleService.updateTitlesByTitle(oldTitle, newTitle);

            return new ResponseEntity<>("Title details updated successfully",HttpStatus.OK);

        } catch (Exception e) {

            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)

                .body("Internal server error");

        }

    }

  
	//Delete title by employee number, from date, and title.
	
	@DeleteMapping("/empno/{empNo}/fromdate/{fromDate}/title/{title}")
    public ResponseEntity<String> deleteTitleByEmpNoFromDateAndTitle(
    		@PathVariable int empNo,
            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate,
            @PathVariable("title") String title) throws TitlesNotFoundException {
		
		titleService.deleteByEmpNoFromDateAndTitle(empNo, fromDate, title);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
	
	  //Delete title by employee number.
	 
	@DeleteMapping("/empno/{empNo}")
    public ResponseEntity<String> deleteTitleByEmpNo(
    		@PathVariable int empNo) throws TitlesNotFoundException {

		titleService.deleteByEmpNo(empNo);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
	
	 //Delete title by from date.
	 
	@DeleteMapping("/fromdate/{fromDate}")
    public ResponseEntity<String> deleteTitleByEmpNoFromDateAndTitle(
            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws TitlesNotFoundException {
		
		titleService.deleteByFromDate(fromDate);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
	
	 //Delete title by title.
	
	@DeleteMapping("/title/{title}")
    public ResponseEntity<String> deleteByTitle(
            @PathVariable("title") String title) throws TitlesNotFoundException {
	
		titleService.deleteByTitle(title);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
	
	
	
	
}
