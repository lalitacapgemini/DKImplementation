package com.cg.training.repository;

import java.time.LocalDate;
import java.util.Collection;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;
import com.cg.training.services.EmployeeService;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
	 

	    List<Employee> findByFirstNameContains(String firstName);

	 

	    List<Employee> findByLastNameContains(String lastName);

	 

	    @Query("SELECT E FROM Employee E WHERE E.gender=?1")
	    List<Employee> findByGenderContains(Gender gender);

	 

	    List<Employee> findByHireDate(LocalDate hireDate);

	    List<Employee> findByBirthDate(LocalDate birthDate);

	 

	    @Query("SELECT E FROM Employee E ORDER BY E.hireDate DESC")
	    List<Employee> findAllByOrderByHireDateDesc();




		 @Query("SELECT e FROM Employee e WHERE e.hireDate >= :tenYearsAgo")
		    List<Employee> findEmployeesHiredAfter(@Param("tenYearsAgo") LocalDate tenYearsAgo);



		 @Query("SELECT e FROM Employee e WHERE e.hireDate >= :tenYearsAgo")
		    List<Employee> findByHireDateGreaterThanEqual(@Param("tenYearsAgo") LocalDate tenYearsAgo);
		 
		 @Query("SELECT COUNT(e) FROM Employee e WHERE e.hireDate >= :hireDate")
		    int countByHireDateGreaterThanEqual(@Param("hireDate") LocalDate hireDate);






		

}




		






		



		 























