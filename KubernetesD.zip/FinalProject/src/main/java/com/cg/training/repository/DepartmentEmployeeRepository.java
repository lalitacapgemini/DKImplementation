package com.cg.training.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.training.entities.DepartmentEmployee;
import com.cg.training.entities.DepartmentEmployeeId;

@Repository
public interface DepartmentEmployeeRepository extends JpaRepository<DepartmentEmployee, DepartmentEmployeeId> {

	
	DepartmentEmployee findByEmployee_EmpNoAndDepartment_DeptNoAndFromDate(int empNo, String deptNo, LocalDate fromDate);

	DepartmentEmployee findByDepartment_DeptNoAndFromDate(String deptNo, LocalDate fromDate);

	DepartmentEmployee findByEmployee_EmpNoAndFromDate(int empNo, LocalDate fromDate);

	DepartmentEmployee findByEmployee_EmpNoAndDepartment_DeptNo(int empNo, String deptNo);

	

	List<DepartmentEmployee> findByDepartmentDeptNoAndFromDate(String deptNo, LocalDate fromDate);


	@Modifying
	@Query("DELETE FROM DepartmentEmployee dm WHERE dm.employee.empNo = :empNo AND dm.department.deptNo = :deptNo AND dm.fromDate = :fromDate")
	String deleteByEmpNoAndDeptNoAndFromDate(@Param("empNo") int empNo, @Param("deptNo") String deptNo,
			@Param("fromDate") LocalDate fromDate);

	@Modifying
	@Query("DELETE FROM DepartmentEmployee dm WHERE dm.employee.empNo = :empNo AND dm.department.deptNo = :deptNo")
	String deleteByEmpNoAndDeptNo(@Param("empNo") int empNo, @Param("deptNo") String deptNo);

	@Modifying
	@Query("DELETE FROM DepartmentEmployee dm WHERE dm.employee.empNo = :empNo AND dm.fromDate = :fromDate")
	String deleteByEmpNoAndFromDate(@Param("empNo") int empNo, @Param("fromDate") LocalDate fromDate);

	@Modifying
	@Query("DELETE FROM DepartmentEmployee dm WHERE dm.department.deptNo = :deptNo AND dm.fromDate = :fromDate")
	String deleteByDeptNoAndFromDate(@Param("deptNo") String deptNo, @Param("fromDate") LocalDate fromDate);

}
