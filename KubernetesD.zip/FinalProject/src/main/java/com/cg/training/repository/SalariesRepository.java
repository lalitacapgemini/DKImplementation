package com.cg.training.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.training.entities.Salaries;
import com.cg.training.entities.SalaryId;


@Repository
public interface SalariesRepository extends JpaRepository<Salaries, SalaryId> {

	List<Salaries> findAllByFromDate(LocalDate fromDate);

	@Query("select s from Salaries s where s.employee.empNo= :emp_no")
	List<Salaries> findSalaryByEmployee(@Param("emp_no") int empNo);

	@Query("SELECT s FROM Salaries s WHERE s.salary >= :minsalary AND s.salary <= :maxsalary")
	List<Salaries> findAllBySalaryBetween(@Param("minsalary") int minSalary, @Param("maxsalary") int maxSalary);

	@Query("select s from Salaries s where s.employee.empNo= :empNo And s.fromDate=:fromDate")
	Salaries findbyempnoandfromdate(@Param("empNo") int empNo, @Param("fromDate") LocalDate fromDate);
	
	@Query("select s from Salaries s where s.employee.empNo= :emp_no")
	Salaries findsSalaryByEmployee(@Param("emp_no") int empNo);
	
	@Query("select s from Salaries s where s.fromDate=:fromDate")
	Salaries findbyfromdate(@Param("fromDate") LocalDate fromDate);
	
	
	

	@Modifying
	@Query("DELETE FROM Salaries s WHERE s.employee.empNo = :empNo AND s.fromDate = :fromDate")
	String deleteByEmployeeEmpNoAndFromDate(@Param("empNo") int empNo, @Param("fromDate") LocalDate fromDate);

	@Modifying
	@Query("DELETE FROM Salaries s WHERE s.fromDate = :fromDate")
	String deleteByFromDate(@Param("fromDate") LocalDate fromDate);

	@Modifying
	@Query("DELETE FROM Salaries s WHERE s.employee.empNo = :empNo")
	String deleteByEmployeeEmpNo(@Param("empNo") int empNo);
}