package com.cg.training.exceptions;

public class EmployeeNotFoundException extends Exception {

	String message;

	public EmployeeNotFoundException(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		return this.message;
	}
}
