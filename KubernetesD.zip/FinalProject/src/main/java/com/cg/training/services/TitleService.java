package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.cg.training.entities.Titles;
import com.cg.training.exceptions.TitlesNotFoundException;

public interface TitleService {

	List<Titles> getTitles();

	Titles addTitle(Titles title);

	List<Titles> getTitleByEmpNoAndDeptNo(int empNo, LocalDate fromDate, String title)throws TitlesNotFoundException;

	List<Titles> getAllByTitle(String title)throws TitlesNotFoundException;

	List<Titles> findAllByFromDate(LocalDate fromDate)throws TitlesNotFoundException;

	List<Titles> getTitleByTitleAndFromDate(LocalDate fromDate, String title)throws TitlesNotFoundException;

	List<Titles> getTitleByTitleAndFromDate(int empNo, String title)throws TitlesNotFoundException;

	List<Titles> getTitleByEmpNoAndFromDate(int empNo, LocalDate fromDate);

	Titles findByEmpNoAndFromDateAndTitle(int empNo, LocalDate fromDate, String title)throws TitlesNotFoundException;

	Titles getByEmpNo(int empNo)throws TitlesNotFoundException;

	Titles findByFromDates(LocalDate fromDate)throws TitlesNotFoundException;

	Titles getbytitle(String title)throws TitlesNotFoundException;

	void deleteByEmpNoFromDateAndTitle(int empNo, LocalDate fromDate, String title)throws TitlesNotFoundException;

	void deleteByEmpNo(int empNo)throws TitlesNotFoundException;

	void deleteByFromDate(LocalDate fromDate)throws TitlesNotFoundException;

	void deleteByTitle(String title)throws TitlesNotFoundException;
	
	public void updateTitlesByEmpNo(int empNo, String newTitle);

	public void updateTitlesByTitle(String oldTitle, String newTitle);

	public void updateTitleByEmpNoAndFromDateAndTitle(int empNo, LocalDate fromDate, String oldTitle, String newTitle);

}