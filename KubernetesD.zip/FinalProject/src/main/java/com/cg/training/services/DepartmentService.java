package com.cg.training.services;

import java.util.List;

import com.cg.training.dto.DepartmentDTO;
import com.cg.training.entities.Departments;
import com.cg.training.exceptions.DepartmentsNotFoundException;

import jakarta.validation.Valid;

public interface DepartmentService {
	public List<Departments> getDepartments();
	public Departments getDepartmentsByDepNo(String deptNo)throws DepartmentsNotFoundException;
	public List<Departments> getDepartmentsByDeptName(String deptName)throws DepartmentsNotFoundException;
	public Departments addDepartment(Departments departments);
	public Departments updateByDeptNo(Departments departments)throws DepartmentsNotFoundException;
	public Departments updateByDeptName(Departments departments)throws DepartmentsNotFoundException;
	public void deleteByDeptNo(String deptNo);
	public void deleteByDeptName(String deptName)throws DepartmentsNotFoundException;
	public static void addDepartment(@Valid DepartmentDTO departmentDTO) {
		
	}
}