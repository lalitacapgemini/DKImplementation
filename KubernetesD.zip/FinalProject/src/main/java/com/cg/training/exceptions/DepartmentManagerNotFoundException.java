package com.cg.training.exceptions;

public class DepartmentManagerNotFoundException extends Exception {
	String message;

	public DepartmentManagerNotFoundException(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		return this.message;
	}
}
