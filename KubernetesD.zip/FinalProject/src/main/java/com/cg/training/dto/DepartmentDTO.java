package com.cg.training.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

public class DepartmentDTO {
    @NotBlank(message = "Department number is required")
    @Size(max = 4, message = "Department number should be at most 4 characters")
    private String deptNo;

    @NotBlank(message = "Department name is required")
    @Size(max = 40, message = "Department name should be at most 40 characters")
    private String deptName;
    
    

	public DepartmentDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getDeptNo() {
		return deptNo;
	}

	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public DepartmentDTO(
			@NotBlank(message = "Department number is required") @Size(max = 4, message = "Department number should be at most 4 characters") String deptNo,
			@NotBlank(message = "Department name is required") @Size(max = 40, message = "Department name should be at most 40 characters") String deptName) {
		super();
		this.deptNo = deptNo;
		this.deptName = deptName;
	}

   
}
