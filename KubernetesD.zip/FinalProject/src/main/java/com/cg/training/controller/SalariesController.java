package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.entities.Salaries;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.exceptions.SalariesNotFoundException;
import com.cg.training.services.SalariesServiceImpl;

import io.swagger.v3.oas.annotations.Operation;

//It contains various endpoints for managing salary data.
@RestController
@RequestMapping("/api/v1/salaries")
public class SalariesController {

    @Autowired
    public SalariesServiceImpl salaryService;
    //Fetch all salary objects.
    @GetMapping("/all")
    public List<Salaries> findAllSalary() {
        return salaryService.getSalary();
    }

    //Fetch salary objects by from date.
    @GetMapping("/fromdate/{fromdate}")
    public List<Salaries> findSalaryByFromDate(
            @PathVariable("fromdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws SalariesNotFoundException {
        return salaryService.getSalaryByFromDate(fromDate);
    }

 
    // Fetch salary objects by employee number.
    @GetMapping("/empno/{empno}")
    public List<Salaries> findSalaryByEmployee(@PathVariable("empno") int empNo) throws SalariesNotFoundException {
        return salaryService.getSalariesByEmployee(empNo);
    }

 
    //Fetch salary objects by salary range.
    @GetMapping("/salary/{minsalary}/{maxsalary}")
    public List<Salaries> findSalaryByRange(@PathVariable("minsalary") int minSalary,
            @PathVariable("maxsalary") int maxSalary) throws SalariesNotFoundException {
        return salaryService.getSalaryByRange(minSalary, maxSalary);
    }
    
  //Fetch salary object by employee number and from date.

    @GetMapping("/empNo/{empNo}/fromDate/{fromDate}")
    public Salaries findSalaryByFromDate(@PathVariable("empNo") int empNo, @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) {
    	
    	return salaryService.getSalaryByEmpNoandFromDate(empNo, fromDate);
    }

 
    //Add a new salary object to the database.
 
    @PostMapping("/add")
    public ResponseEntity<String> addSalaryC(@RequestBody Salaries salary) {
  
        Salaries response = salaryService.addSalary(salary);
        if (response != null)
            return new ResponseEntity<String>("New Salary details added Successfully", HttpStatus.OK);
        else
            throw new InvalidDataException("Validation Failed: ");
    }

    //Update salary by from date.
     
    @PutMapping("/fromdate/{fromDate}")
    public ResponseEntity<Salaries> updateSalaryByEmpNoAndFromDate(
            @RequestBody Salaries salary,
            @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws SalariesNotFoundException {
        Salaries existingSalary = salaryService.getSalaryByFromDates(fromDate);
        
        if (existingSalary != null) {
            existingSalary.setSalary(salary.getSalary());
            existingSalary.setToDate(salary.getToDate());
            Salaries updatedSalary = salaryService.updateSalary(existingSalary);
            return ResponseEntity.ok(updatedSalary);
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }
    
    //Update salary by employee number and from date.

    @PutMapping("/empno/{empNo}/fromdate/{fromDate}")
    public ResponseEntity<Salaries> updateSalaryByEmpNoAndFromDate(
            @RequestBody Salaries salary,
            @PathVariable int empNo,
            @PathVariable("fromDate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws SalariesNotFoundException {
    	
        Salaries existingSalary = salaryService.getSalaryByEmpNoandFromDate(empNo, fromDate);
        
        if (existingSalary != null) {
            existingSalary.setSalary(salary.getSalary());
            Salaries updatedSalary = salaryService.updateSalary(existingSalary);
            return ResponseEntity.ok(updatedSalary);
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

     //Update salary by employee number.
   
    @PutMapping("/empno/{empNo}")
    public ResponseEntity<Salaries> updateSalaryByEmpNoAndFromDate(
            @RequestBody Salaries salary,
            @PathVariable int empNo) throws SalariesNotFoundException {
    	
        Salaries existingSalary = salaryService.getSalariesByEmployees(empNo);
        
        if (existingSalary != null) {
            existingSalary.setSalary(salary.getSalary());
            existingSalary.setToDate(salary.getToDate());
            Salaries updatedSalary = salaryService.updateSalary(existingSalary);
            return ResponseEntity.ok(updatedSalary);
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    /*
     * Delete salary by employee number and from date.
     * Returns a success message if the deletion is successful.
     */    

    
    @DeleteMapping("/empno/{empNo}/fromdate/{fromDate}")
    public ResponseEntity<String> deleteSalaryByEmpNoAndFromDate(
        @PathVariable int empNo,
        @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws SalariesNotFoundException {
        
        salaryService.deleteByEmpNoAndFromDate(empNo, fromDate);
        return new ResponseEntity<>("Salary deleted successfully", HttpStatus.OK);
    }

	
	//Delete salary by from date.
   
	@DeleteMapping("/fromdate/{fromDate}")
    public ResponseEntity<String> deleteTitleByEmpNoFromDate(
            @PathVariable @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate fromDate) throws SalariesNotFoundException {
		
		salaryService.deleteByFromDate(fromDate);
        return new ResponseEntity<>("Salary deleted successfully",HttpStatus.OK);
    }
	
	  //Delete salary by employee number.
	
	@DeleteMapping("/empno/{empNo}")
    public ResponseEntity<String> deleteTitleByEmpNo(
    		@PathVariable int empNo) throws SalariesNotFoundException {
		
		salaryService.deleteByEmpNo(empNo);
        return new ResponseEntity<>("Title deleted successfully",HttpStatus.OK);
    }
    
    
    
}
    
