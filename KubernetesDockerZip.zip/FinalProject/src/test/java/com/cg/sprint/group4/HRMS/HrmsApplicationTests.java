/*
 * package com.cg.sprint.group4.HRMS;
 * 
 * 
 * 
 * import org.junit.jupiter.api.Test;
 * 
 * import org.springframework.boot.test.context.SpringBootTest;
 * 
 * 
 * 
 * @SpringBootTest
 * 
 * class HrmsApplicationTests {
 * 
 * 
 * 
 * //@Test
 * 
 * void contextLoads() {
 * 
 * }
 * 
 * 
 * 
 * }
 */