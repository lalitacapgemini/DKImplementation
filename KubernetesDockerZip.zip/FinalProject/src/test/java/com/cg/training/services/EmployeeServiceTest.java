/*
 * package com.cg.training.services;
 * 
 * import com.cg.training.entities.Employee; import
 * com.cg.training.entities.Gender; import
 * com.cg.training.exceptions.EmployeeNotFoundException; import
 * com.cg.training.repository.EmployeeRepository;
 * 
 * import org.junit.jupiter.api.BeforeEach; import org.junit.jupiter.api.Test;
 * import org.mockito.InjectMocks; import org.mockito.Mock; import
 * org.mockito.MockitoAnnotations; import java.time.LocalDate; import
 * java.util.ArrayList; import java.util.List; import static
 * org.junit.jupiter.api.Assertions.assertEquals; import static
 * org.mockito.Mockito.*;
 * 
 * public class EmployeeServiceTest {
 * 
 * @Mock private EmployeeRepository employeeRepository; // Replace with your
 * actual repository class
 * 
 * @InjectMocks private EmployeeServiceImpl employeeService; // Replace with
 * your actual service class
 * 
 * @BeforeEach public void setup() { // Initialize mockito annotations
 * MockitoAnnotations.initMocks(this); }
 * 
 * @Test public void testGetEmployee() { // Arrange List<Employee> employees =
 * new ArrayList<>(); employees.add(new Employee(10001,
 * LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findAll()).thenReturn(employees); List<Employee>
 * result = employeeService.getEmployee(); assertEquals(1, result.size());
 * assertEquals(employees.get(0), result.get(0)); }
 * 
 * @Test public void testGetEmployeeById() throws EmployeeNotFoundException { //
 * Arrange int empNo = 10001; Employee expectedEmployee = new Employee(empNo,
 * LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26"));
 * when(employeeRepository.findById(empNo)).thenReturn(java.util.Optional.
 * ofNullable(expectedEmployee)); Employee result =
 * employeeService.getEmployeeById(empNo); assertEquals(expectedEmployee,
 * result); }
 * 
 * @Test public void testGetEmployeeByFirstName() throws
 * EmployeeNotFoundException { // Arrange String firstName = "Georgi";
 * List<Employee> employees = new ArrayList<>(); employees.add(new
 * Employee(10001, LocalDate.parse("1953-09-02"), firstName, "Facello",
 * Gender.M, LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findByFirstNameContains(firstName)).thenReturn(
 * employees); List<Employee> result =
 * employeeService.getEmployeeByFirstName(firstName); assertEquals(1,
 * result.size()); assertEquals(firstName, result.get(0).getFirstName()); }
 * 
 * @Test public void testGetEmployeeByLastName() throws
 * EmployeeNotFoundException { // Arrange String lastName = "Facello";
 * List<Employee> employees = new ArrayList<>(); employees.add(new
 * Employee(10001, LocalDate.parse("1953-09-02"), "Georgi", lastName, Gender.M,
 * LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findByLastNameContains(lastName)).thenReturn(
 * employees); List<Employee> result =
 * employeeService.getEmployeeByLastName(lastName); assertEquals(1,
 * result.size()); assertEquals(lastName, result.get(0).getLastName()); }
 * 
 * @Test public void testGetEmployeesByGender() { // Arrange Gender gender =
 * Gender.M; List<Employee> employees = new ArrayList<>(); employees.add(new
 * Employee(10001, LocalDate.parse("1953-09-02"), "Georgi", "Facello", gender,
 * LocalDate.parse("1986-06-26")));
 * when(employeeRepository.findByGenderContains(gender)).thenReturn(employees);
 * List<Employee> result = employeeService.getEmployeesByGender(gender);
 * assertEquals(1, result.size()); assertEquals(gender,
 * result.get(0).getGender()); }
 * 
 * @Test public void testAddEmployee() throws EmployeeNotFoundException {
 * Employee newEmployee = new Employee(10002, LocalDate.parse("1964-06-02"),
 * "Bezalel", "Simmel", Gender.F, LocalDate.parse("1985-11-21"));
 * when(employeeRepository.save(newEmployee)).thenReturn(newEmployee); Employee
 * result = employeeService.addEmployee(newEmployee); assertEquals(newEmployee,
 * result); }
 * 
 * @Test public void testUpdateEmployeeBirthDate() throws
 * EmployeeNotFoundException { int empNo = 10001; LocalDate newBirthDate =
 * LocalDate.parse("1960-01-01"); Employee employeeToUpdate = new
 * Employee(empNo, LocalDate.parse("1953-09-02"), "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26")); Employee updatedEmployee = new
 * Employee(empNo, newBirthDate, "Georgi", "Facello", Gender.M,
 * LocalDate.parse("1986-06-26"));
 * when(employeeRepository.findById(empNo)).thenReturn(java.util.Optional.
 * ofNullable(employeeToUpdate));
 * when(employeeRepository.save(employeeToUpdate)).thenReturn(updatedEmployee);
 * Employee result = employeeService.updateEmployeeBirthDate(employeeToUpdate,
 * empNo); assertEquals(updatedEmployee.getBirthDate(), result.getBirthDate());
 * } }
 * 
 */