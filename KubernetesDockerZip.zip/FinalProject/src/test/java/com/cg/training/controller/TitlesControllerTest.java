/*
 * package com.cg.training.controller; import static org.mockito.Mockito.*;
 * import java.time.LocalDate; import java.util.ArrayList; import
 * java.util.List; import org.junit.jupiter.api.BeforeEach; import
 * org.junit.jupiter.api.Test; import org.mockito.InjectMocks; import
 * org.mockito.Mock; import org.mockito.MockitoAnnotations; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.http.ResponseEntity; import
 * com.cg.training.controller.TitlesController; import
 * com.cg.training.entities.Titles; import
 * com.cg.training.exceptions.TitlesNotFoundException; import
 * com.cg.training.services.TitleServiceImpl; import static
 * org.junit.jupiter.api.Assertions.*;
 * 
 * public class TitlesControllerTest {
 * 
 * @Mock private TitleServiceImpl titleService;
 * 
 * @InjectMocks private TitlesController titlesController;
 * 
 * @BeforeEach public void setup() { MockitoAnnotations.initMocks(this); }
 * 
 * @Test public void testFindAllTitles() { List<Titles> titlesList = new
 * ArrayList<>();
 * 
 * 
 * when(titleService.getTitles()).thenReturn(titlesList);
 * 
 * List<Titles> result = titlesController.findAllSalary();
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testAddNewTitles() throws TitlesNotFoundException { Titles
 * titles = new Titles(10001, LocalDate.parse("2001-01-01"),
 * LocalDate.parse("2002-01-01"), "Engineer"); // Create a Titles object as
 * needed
 * 
 * when(titleService.addTitle(titles)).thenReturn(titles);
 * 
 * ResponseEntity<Titles> response = titlesController.addNewTitles(titles);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode()); assertEquals(titles,
 * response.getBody()); }
 * 
 * @Test public void testFindByEmpNoAndFromDateAndTitle() throws
 * TitlesNotFoundException { int empNo = 10001; LocalDate fromDate =
 * LocalDate.parse("2001-01-01"); String title = "Engineer";
 * 
 * List<Titles> titlesList = new ArrayList<>();
 * 
 * 
 * when(titleService.getTitleByEmpNoAndDeptNo(empNo, fromDate,
 * title)).thenReturn(titlesList);
 * 
 * List<Titles> result = titlesController.findByEmpNoAndFromDateAndTitle(empNo,
 * fromDate, title);
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testFindAllByTitle() throws TitlesNotFoundException {
 * String title = "Engineer"; List<Titles> titlesList = new ArrayList<>();
 * 
 * when(titleService.getAllByTitle(title)).thenReturn(titlesList);
 * 
 * List<Titles> result = titlesController.findAllByTitle(title);
 * 
 * assertEquals(titlesList, result); }
 * 
 * @Test public void testFindByFromDate() throws TitlesNotFoundException {
 * LocalDate fromDate = LocalDate.parse("2001-01-01"); List<Titles> titlesList =
 * new ArrayList<>();
 * 
 * when(titleService.findAllByFromDate(fromDate)).thenReturn(titlesList);
 * 
 * List<Titles> result = titlesController.findByFromDate(fromDate);
 * 
 * assertEquals(titlesList, result); }
 * 
 * 
 * @Test public void testDeleteTitleByEmpNoFromDateAndTitle() throws
 * TitlesNotFoundException { int empNo = 10001; LocalDate fromDate =
 * LocalDate.parse("2001-01-01"); String title = "Engineer";
 * 
 * ResponseEntity<String> response =
 * titlesController.deleteTitleByEmpNoFromDateAndTitle(empNo, fromDate, title);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("Title deleted successfully", response.getBody()); }
 * 
 * @Test public void testDeleteTitleByEmpNo() throws TitlesNotFoundException {
 * int empNo = 10001;
 * 
 * ResponseEntity<String> response = titlesController.deleteTitleByEmpNo(empNo);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("Title deleted successfully", response.getBody()); }
 * 
 * @Test public void testDeleteTitleByFromDate() throws TitlesNotFoundException
 * { LocalDate fromDate = LocalDate.parse("2001-01-01");
 * 
 * ResponseEntity<String> response =
 * titlesController.deleteTitleByEmpNoFromDateAndTitle(fromDate);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("Title deleted successfully", response.getBody()); }
 * 
 * @Test public void testDeleteByTitle() throws TitlesNotFoundException { String
 * title = "Engineer";
 * 
 * ResponseEntity<String> response = titlesController.deleteByTitle(title);
 * 
 * assertEquals(HttpStatus.OK, response.getStatusCode());
 * assertEquals("Title deleted successfully", response.getBody()); } }
 */