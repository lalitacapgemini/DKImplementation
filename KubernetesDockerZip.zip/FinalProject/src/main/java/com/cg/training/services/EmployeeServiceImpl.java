package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;
import com.cg.training.repository.EmployeeRepository;



@Service
public class EmployeeServiceImpl implements EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;
    

	public List<Employee> getEmployee() {
        return employeeRepository.findAll();
    }
    
    
    public Employee getEmployeeById(int id) {
        return employeeRepository.findById(id).orElse(null);
    }
    
    public List<Employee> getEmployeeByFirstName(String firstName) {
        return employeeRepository.findByFirstNameContains(firstName);
    }
    
    public List<Employee> getEmployeeByLastName(String lastName) {
        return employeeRepository.findByLastNameContains(lastName);
    }
    
   
    public List<Employee> getEmployeesByGender(Gender gender) {
        try {
            List<Employee> records = employeeRepository.findByGenderContains(gender);
            System.out.println(records);
            return records;
        } catch (Exception ex) {
            System.out.println(ex.getMessage());
            return null;
        }
    }
    
  
    public List<Employee> getEmployeesByHireDate(LocalDate hireDate) {
        return employeeRepository.findByHireDate(hireDate);
    }
    
   
    public List<Employee> getEmployeesByBirthDate(LocalDate birthDate) {
        return employeeRepository.findByBirthDate(birthDate);
    }
    
  
    public List<Employee> getAllEmployeesSortedByHireDateDesc() {
        return employeeRepository.findAllByOrderByHireDateDesc();
    }

    public Employee addEmployee(Employee employee) {
        Employee newEmployee = employeeRepository.save(employee);
        return newEmployee;
    }
    
 
    public Employee updateEmployee(Employee employee) {
        Employee readEmployee = employeeRepository.findById(employee.getEmpNo()).orElse(null);
        readEmployee.setFirstName(employee.getFirstName());
        readEmployee.setLastName(employee.getLastName());
        readEmployee.setBirthDate(employee.getBirthDate());
        readEmployee.setHireDate(employee.getHireDate());
        return employeeRepository.save(readEmployee);
    }
    
   
    public Employee updateEmployeeLastName(Employee employee, int empNo) {
        Employee readEmployee = employeeRepository.findById(empNo).orElse(null);
        if (readEmployee != null) {
            readEmployee.setLastName(employee.getLastName());
            return employeeRepository.save(readEmployee);
        }
        return null;
    }
    
   
    public Employee updateEmployeeFirstName(Employee employee, int empNo) {
        Employee readEmployee = employeeRepository.findById(empNo).orElse(null);
        if (readEmployee != null) {
            readEmployee.setFirstName(employee.getFirstName());
            return employeeRepository.save(readEmployee);
        }
        return null;
    }
    
 
    public Employee updateEmployeeByHireDate(Employee employee, int empNo) {
        Employee readEmployee = employeeRepository.findById(empNo).orElse(null);
        readEmployee.setHireDate(employee.getHireDate());
        return employeeRepository.save(readEmployee);
    }

    public Employee updateEmployeeBirthDate(Employee employee, int empNo) {
        Employee readEmployee = employeeRepository.findById(empNo).orElse(null);
        readEmployee.setBirthDate(employee.getBirthDate());
        return employeeRepository.save(readEmployee);
    }
}
