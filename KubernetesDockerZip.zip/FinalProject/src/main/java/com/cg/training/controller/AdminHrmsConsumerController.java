package com.cg.training.controller;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.training.dto.AssignDepartmentDto;
import com.cg.training.dto.DepartmentDTO;
import com.cg.training.dto.DepartmentEmployeeDto;
import com.cg.training.dto.EmployeeDto;
import com.cg.training.dto.TitlesDto;
import com.cg.training.services.AdminHrmsConsumerService;
import com.cg.training.services.DepartmentService;
import com.cg.training.services.EmployeeService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("api/v1/adminhrmsconsumer")
public class AdminHrmsConsumerController {

	@Autowired
	private AdminHrmsConsumerService adminhrmsconsumerservice;


	@Autowired
	private EmployeeDto employeeservice;
	
	@GetMapping("/employees/{noofyear}")
    public ResponseEntity<Collection<EmployeeDto>> getEmployeesJoinedLast10Years(@PathVariable int noofyear) {
        Collection<EmployeeDto> employees = adminhrmsconsumerservice.getEmployeesJoinedinLast10Years(noofyear);
        return ResponseEntity.ok(employees);
	}
	
	//CountEmployee Join in Last Date
	 @GetMapping("/count/{noOfYears}")
	    public ResponseEntity<Integer> countEmployeesJoinedLast10Years(@PathVariable int noOfYears) {
	        int count = employeeservice.countEmployeesJoinedLast10Years(noOfYears);
	        return ResponseEntity.ok(count);
	    }
	 
	 //Assign Department
	 @PostMapping("/assigndept")
	    public ResponseEntity<String> assignDepartment(@RequestBody AssignDepartmentDto assignDepartmentDto) {
		 adminhrmsconsumerservice.assignDepartment(assignDepartmentDto);
	        return ResponseEntity.ok("Employee is assigned to the department successfully.");
	    }
	 
	 //addDepartment
	 @PostMapping("/department")
	 public ResponseEntity<String> addDepartment(@Valid @RequestBody DepartmentDTO departmentDTO) {
	     try {
	         DepartmentService.addDepartment(departmentDTO);
	         return ResponseEntity.ok("Department is added successfully.");
	     } catch (Exception e) {
	         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
	             .body("An error occurred while adding the department.");
	     }
	 }
	 
	 //add Employee
	 @PostMapping("/employee")
	    public ResponseEntity<String> addEmployee(@RequestBody EmployeeDto employeeDTO) {
		 adminhrmsconsumerservice.addEmployee(employeeDTO);
	        return ResponseEntity.ok("Employee is added successfully.");
	    }





}