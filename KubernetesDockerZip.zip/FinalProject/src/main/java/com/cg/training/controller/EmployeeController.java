package com.cg.training.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;
import com.cg.training.exceptions.EmployeeNotFoundException;
import com.cg.training.exceptions.InvalidDataException;
import com.cg.training.exceptions.NotFoundException;
import com.cg.training.services.EmployeeServiceImpl;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/v1/employees")
public class EmployeeController {

	@Autowired
	public EmployeeServiceImpl employeeService;
	

	@PostMapping("/create")

	public void createDepartment(@Valid @RequestBody Employee e)

	{
		employeeService.addEmployee(e);

	}
	
	

	//Fetch Employee
	@GetMapping("/all")
	public List<Employee> findAllEmployees() {
		
		return employeeService.getEmployee();
	}

	
	//Fetch Employee by employee number
	@GetMapping("/{id}")
	public Employee findEmployeeById(@PathVariable int id) throws EmployeeNotFoundException { // Change
		
		if (employeeService.getEmployeeById(id) != null)
			return employeeService.getEmployeeById(id);
		else
			throw new NotFoundException("Employee Id is not correct! Please check again");
	}

	//Fetch Employee by First Name
	@GetMapping("/firstname/{firstName}")
	public List<Employee> findEmployeeByFirstName(@PathVariable("firstName") String firstName) throws EmployeeNotFoundException {
	
		if (employeeService.getEmployeeByFirstName(firstName) != null)
			return employeeService.getEmployeeByFirstName(firstName);
		else
			throw new NotFoundException("First Name is not correct! Please Check again.");
	}
	
	//Fetch Employee by Last Name
	@GetMapping("/lastname/{lastName}")
	public List<Employee> findEmployeeByLastName(@PathVariable("lastName") String lastName) throws EmployeeNotFoundException {
		
		return employeeService.getEmployeeByLastName(lastName);
	}

	//Fetch Employee by Gender
	@GetMapping("/gender/{gender}")
	public List<Employee> findByGender(@PathVariable("gender") String gender) {
		
		Gender g = Gender.valueOf(gender);
		return employeeService.getEmployeesByGender(g);
	}

	//Fetch Employee by HireDate
	@GetMapping("/hiredate/{hiredate}")
	public List<Employee> findEmployeesByHireDate(
			@PathVariable("hiredate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate hireDate) throws EmployeeNotFoundException {
		
		return employeeService.getEmployeesByHireDate(hireDate);
	}

	////Fetch Employee by BirthDate
	@GetMapping("/birthdate/{birthdate}")
	public List<Employee> findEmployeesByBirthDate(
			@PathVariable("birthdate") @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate birthDate) throws EmployeeNotFoundException {
		
		return employeeService.getEmployeesByBirthDate(birthDate);
	}
	
	//Add
	@PostMapping("/add")
	public ResponseEntity<String> addEmployeeC(@RequestBody Employee employee) throws EmployeeNotFoundException {
	
		Employee response = employeeService.addEmployee(employee);
		if (response != null)
			return new ResponseEntity<String>("New employee added successfully", HttpStatus.OK);
		else
			throw new InvalidDataException("Validation Failed: Invalid entry.Please Check again");
	}

	//updateEmployeeByLastName
	@PutMapping("/lastname/{empno}")
	public ResponseEntity<Employee> updateEmployeeByLastNameC(@PathVariable("empno") int empNo,
			@RequestBody Employee employee) throws EmployeeNotFoundException {
		
		Employee emp = employeeService.updateEmployeeLastName(employee, empNo);

		if (emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			throw new NotFoundException("Invalid Id: Unable to update the lastname");
	}

	//updateEmployeeByFirstNameC
	@PutMapping("/firstname/{empno}")
	public ResponseEntity<Employee> updateEmployeeByFirstNameC(@PathVariable("empno") int empNo,
			@RequestBody Employee employee) throws EmployeeNotFoundException {
		
		Employee emp = employeeService.updateEmployeeFirstName(employee, empNo);
		if (emp != null)
			return new ResponseEntity<Employee>(emp, HttpStatus.OK);
		else
			throw new NotFoundException("Invalid Id: Unable to update the firstname");
	}

	// updateEmployeeByHireDateC
	@PutMapping("/hiredate/{empno}")
	public Employee updateEmployeeByHireDateC(@PathVariable("empno") int empNo, @RequestBody Employee employee) throws EmployeeNotFoundException {
		
		return employeeService.updateEmployeeByHireDate(employee, empNo);
	}

	//updateEmployeeByBirthDateC
	@PutMapping("/birthdate/{empno}")
	public Employee updateEmployeeByBirthDateC(@PathVariable("empno") int empNo, @RequestBody Employee employee) throws EmployeeNotFoundException {
		
		return employeeService.updateEmployeeBirthDate(employee, empNo);
	}

}