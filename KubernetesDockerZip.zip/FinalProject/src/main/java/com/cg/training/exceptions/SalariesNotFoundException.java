package com.cg.training.exceptions;

public class SalariesNotFoundException extends Exception {


	String message;

	public SalariesNotFoundException(String message) {
		super();
		this.message = message;
	}
	
	public String getMessage() {
		return this.message;
	}
}
