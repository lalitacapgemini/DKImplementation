package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import com.cg.training.entities.DepartmentEmployee;
import com.cg.training.exceptions.DepartmentEmployeeNotFoundException;

public interface DepartmentEmployeeService {
	public List<DepartmentEmployee> getdepartmentemployee();
	public List<DepartmentEmployee> findByDeptNoAndFromDate(String deptNo, LocalDate fromDate)throws DepartmentEmployeeNotFoundException;
	public DepartmentEmployee findBysDeptNoAndFromDate(String deptNo, LocalDate fromDate)throws DepartmentEmployeeNotFoundException;
	public DepartmentEmployee findByempNoAndFromDate(int empNo, LocalDate fromDate)throws DepartmentEmployeeNotFoundException;
	public DepartmentEmployee getDepartEmployeeByEmpNoAndDeptNo(int empNo, String deptNo)throws DepartmentEmployeeNotFoundException;
	public DepartmentEmployee getDepartmentEmployeeByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo, LocalDate fromDate)throws DepartmentEmployeeNotFoundException;
	public DepartmentEmployee updateDepartmentEmployee(DepartmentEmployee departmentEmployee)throws DepartmentEmployeeNotFoundException;
	public DepartmentEmployee saveDepartmentEmployee(DepartmentEmployee departmentEmployee);
	public void deleteByEmpNoAndDeptNoAndFromDate(int empNo, LocalDate fromDate, String deptNo)throws DepartmentEmployeeNotFoundException;
	public void deleteByEmpNoAndDeptNo(int empNo, String deptNo)throws DepartmentEmployeeNotFoundException;
	public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate)throws DepartmentEmployeeNotFoundException;
	public void deleteByDeptNoAndFromDate(String deptNo, LocalDate fromDate)throws DepartmentEmployeeNotFoundException;
	 
	
}
