package com.cg.training.uicontroller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cg.training.entities.Departments;
import com.cg.training.exceptions.DepartmentsNotFoundException;
import com.cg.training.services.DepartmentService;

import java.util.*;



@Controller
@RequestMapping("/api/ui/departments")
public class DepartmentsUIController {
	
	@Autowired
    DepartmentService  departmentsService;
	
	//alldepartment.html
	@RequestMapping(method = RequestMethod.GET , value="/all")
	public String getAllDepartments(Model model) {
		List<Departments> departments=departmentsService.getDepartments();
		model.addAttribute("departments", departments);
		return "allDepartments";
	}
	
	// deletedepartments
	@RequestMapping(method = RequestMethod.GET , value="/delete/{deptNo}")
	public String getDepartmentsAddForm(@PathVariable("deptNo") String deptNo) throws DepartmentsNotFoundException {
		System.out.println(deptNo);
		departmentsService.deleteByDeptNo(deptNo);
		return "redirect:/api/ui/departments/all";
	}
	
	//getDepartment
	 @GetMapping(value = "/add")
	    public String getDepartmentsAddForm(Model model) {
	        Departments newDepartment = new Departments();
	        model.addAttribute("newDepartment", newDepartment);
	        return "addDepartments";
	    }

	    @PostMapping(value = "/add")
	    public String addNewDepartment(@ModelAttribute("newDepartment") Departments departments) {
	        departmentsService.addDepartment(departments);
	        return "redirect:/api/ui/departments/all";
	    }
	
	//getDepartmentsByDepNo
	@RequestMapping(method = RequestMethod.GET , value="/view/{deptNo}")
	public String getDepartmentsByDepNo(Model model, @PathVariable("deptNo") String deptNo) throws DepartmentsNotFoundException   {
		Departments departments=departmentsService.getDepartmentsByDepNo(deptNo);
		model.addAttribute("departments", departments);
		return "oneDepartment";
	}
	
	 @GetMapping("/update/{deptNo}")
	    public String getUpdateDepartmentForm(@PathVariable("deptNo") String deptNo, Model model) throws DepartmentsNotFoundException {
	        // Retrieve the department data for the form
	        Departments department = departmentsService.getDepartmentsByDepNo(deptNo);
	        // Populate the model with the department data
	        model.addAttribute("updatedDepartment", department);
	        return "updateDepartment"; // Return the view template
	    }

	    // Handle form submission
	 @PostMapping("/update/{deptNo}")
	    public String updateDepartment(
	        @PathVariable String deptNo,
	        @ModelAttribute("updatedDepartment") Departments updatedDepartment,
	        Model model
	    ) {
	        try {
	            departmentsService.updateByDeptNo(updatedDepartment);
	            return "redirect:/api/ui/departments/all"; // Redirect to the department list page
	        } catch (DepartmentsNotFoundException e) {
	            return "error"; // Create an error template
	        }
	    }
	









}
