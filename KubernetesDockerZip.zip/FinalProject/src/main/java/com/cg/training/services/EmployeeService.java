package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;

import com.cg.training.entities.Employee;
import com.cg.training.entities.Gender;
import com.cg.training.exceptions.EmployeeNotFoundException;

public interface EmployeeService {

	List<Employee> getEmployee();

	Employee getEmployeeById(int id)throws EmployeeNotFoundException;

	List<Employee> getEmployeeByFirstName(String firstName)throws EmployeeNotFoundException;

	List<Employee> getEmployeeByLastName(String lastName)throws EmployeeNotFoundException;

	List<Employee> getEmployeesByGender(Gender gender);

	List<Employee> getEmployeesByHireDate(LocalDate hireDate)throws EmployeeNotFoundException;

	List<Employee> getEmployeesByBirthDate(LocalDate birthDate)throws EmployeeNotFoundException;

	List<Employee> getAllEmployeesSortedByHireDateDesc()throws EmployeeNotFoundException;

	Employee addEmployee(Employee employee)throws EmployeeNotFoundException;

	Employee updateEmployee(Employee employee)throws EmployeeNotFoundException;

	Employee updateEmployeeLastName(Employee employee, int empNo)throws EmployeeNotFoundException;

	Employee updateEmployeeFirstName(Employee employee, int empNo)throws EmployeeNotFoundException;

	Employee updateEmployeeByHireDate(Employee employee, int empNo)throws EmployeeNotFoundException;

	Employee updateEmployeeBirthDate(Employee employee, int empNo)throws EmployeeNotFoundException;

}