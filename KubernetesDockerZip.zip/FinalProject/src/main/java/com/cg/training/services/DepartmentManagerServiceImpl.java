package com.cg.training.services;

import java.time.LocalDate;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.training.entities.DepartmentManager;
import com.cg.training.exceptions.DepartmentManagerNotFoundException;
import com.cg.training.repository.DepartmentManagerRepository;

/**
 * This class implements the DepartmentManagerService interface and provides the business logic for managing department managers.
 */
@Service
public class DepartmentManagerServiceImpl implements DepartmentManagerService{

	@Autowired
	private DepartmentManagerRepository departmentManagerRespository;
	

	
	public List<DepartmentManager> getDepartmentManager() {
		return departmentManagerRespository.findAll();
	}

	
	public DepartmentManager getDepartmentManagersByEmpNoAndDeptNo(int empNo, String deptNo) throws DepartmentManagerNotFoundException {
	    DepartmentManager departmentManager = departmentManagerRespository.findByEmployee_EmpNoAndDepartment_DeptNo(empNo, deptNo);

	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("Department manager not found for empNo: " + empNo + " and deptNo: " + deptNo);
	    }

	    return departmentManager;
	}


	
	public List<DepartmentManager> findByDeptNoAndFromDate(String deptNo, LocalDate fromDate) throws DepartmentManagerNotFoundException {
	    List<DepartmentManager> departmentManagers = departmentManagerRespository.findByDepartmentDeptNoAndFromDate(deptNo, fromDate);

	    if (departmentManagers.isEmpty()) {
	        throw new DepartmentManagerNotFoundException("No department managers found for deptNo: " + deptNo + " and fromDate: " + fromDate);
	    }

	    return departmentManagers;
	}

	
	
	public DepartmentManager findByEmpNoAndFromDate(int empNo, LocalDate fromDate) throws DepartmentManagerNotFoundException {
	    DepartmentManager departmentManager = departmentManagerRespository.findByEmployee_EmpNoAndFromDate(empNo, fromDate);

	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for empNo: " + empNo + " and fromDate: " + fromDate);
	    }

	    return departmentManager;
	}


	
	public DepartmentManager getDepartmentManagersByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo, LocalDate fromdate) throws DepartmentManagerNotFoundException {
	    DepartmentManager departmentManager = departmentManagerRespository.findByEmployee_EmpNoAndDepartment_DeptNoAndFromDate(empNo, deptNo, fromdate);

	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for empNo: " + empNo + ", deptNo: " + deptNo + " and fromDate: " + fromdate);
	    }

	    return departmentManager;
	}

	public DepartmentManager saveDepartmentManager(DepartmentManager departmentManager) {
		if (departmentManager != null)
			return departmentManagerRespository.save(departmentManager);
		else
			return null;
	}
		
	public DepartmentManager updateByEmpNoAndDeptNo(DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
	    // Check if departmentManager is null
	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("DepartmentManager is null. Cannot perform update.");
	    }

	    // Perform the update or save operation
	    return departmentManagerRespository.save(departmentManager);
	}


	
	public DepartmentManager updateByEmpNoAndFromDate(DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
	    // Check if departmentManager is null
	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("DepartmentManager is null. Cannot perform update.");
	    }

	    // Perform the update or save operation
	    return departmentManagerRespository.save(departmentManager);
	}


	
	public DepartmentManager updateByDeptNoAndFromDate(DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
	   
	    // Check if departmentManager is null
	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("DepartmentManager is null. Cannot perform update.");
	    }

	    // Perform the update or save operation
	    return departmentManagerRespository.save(departmentManager);
	}


	
	public DepartmentManager updateByEmpNoAndDeptNoAndFromDate(DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
	    // Check if departmentManager is null
	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("DepartmentManager is null. Cannot perform update.");
	    }

	    // Perform the update or save operation
	    return departmentManagerRespository.save(departmentManager);
	}


	
	public DepartmentManager updatebydeptnoAndfromdate(DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
	    // Perform the update or save operation
	    DepartmentManager updatedManager = departmentManagerRespository.save(departmentManager);

	    if (updatedManager == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for the given criteria.");
	    }

	    return updatedManager;
	}

	
	public DepartmentManager updatebyempnoAnddeptnoAndfromdate(DepartmentManager departmentManager) throws DepartmentManagerNotFoundException {
	    DepartmentManager updatedManager = departmentManagerRespository.save(departmentManager);

	    if (updatedManager == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for the given criteria.");
	    }

	    return updatedManager;
	}


	
	@Transactional
	public void deleteByEmpNoAndDeptNoAndFromDate(int empNo, LocalDate fromDate, String deptNo) throws DepartmentManagerNotFoundException {
	     String deletedCount = departmentManagerRespository.deleteByEmpNoAndDeptNoAndFromDate(empNo, deptNo, fromDate);

	    if (deletedCount == null) {
	        String message = "No department manager found for the given criteria.";
			throw new DepartmentManagerNotFoundException(message);
	    }
	}

	
	@Transactional
	public void deleteByEmpNoAndDeptNo(int empNo, String deptNo) throws DepartmentManagerNotFoundException {
	    // Perform the delete operation
	     String deletedCount = departmentManagerRespository.deleteByEmpNoAndDeptNo(empNo, deptNo);

	    if (deletedCount == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for the given criteria.");
	    }
	}


	
	@Transactional
	public void deleteByEmpNoAndFromDate(int empNo, LocalDate fromDate)throws DepartmentManagerNotFoundException {
	    String deletedCount = departmentManagerRespository.deleteByEmpNoAndFromDate(empNo, fromDate);

	    if (deletedCount == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for the given criteria.");
	    }
	}

	
	@Transactional
	public void deleteByDeptNoAndFromDate(String deptNo, LocalDate fromDate) throws DepartmentManagerNotFoundException {
	    // Perform the delete operation
	    String deletedCount = departmentManagerRespository.deleteByDeptNoAndFromDate(deptNo, fromDate);

	    if (deletedCount == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for the given criteria.");
	    }
	}
	
	public DepartmentManager getDepartmentManagerByEmpNoAndDeptNoAndFromDate(int empNo, String deptNo, LocalDate fromDate)throws DepartmentManagerNotFoundException {
	    DepartmentManager departmentManager = departmentManagerRespository.findByEmployee_EmpNoAndDepartment_DeptNoAndFromDate(empNo, deptNo, fromDate);

	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for the given criteria.");
	    }

	    return departmentManager;
	}



	
	public DepartmentManager getDepartmentDeptNoAndFromDate(String deptNo, LocalDate fromDate) throws DepartmentManagerNotFoundException {
	    DepartmentManager departmentManager = departmentManagerRespository.findByDepartment_DeptNoAndFromDate(deptNo, fromDate);

	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for the given criteria.");
	    }

	    return departmentManager;
	}


	
	public DepartmentManager getDepartmentManagerByEmpNoAndDeptNo(int empNo, String deptNo) throws DepartmentManagerNotFoundException {
	    DepartmentManager departmentManager = departmentManagerRespository.findByEmployee_EmpNoAndDepartment_DeptNo(empNo, deptNo);

	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for empNo: " + empNo + " and deptNo: " + deptNo);
	    }

	    return departmentManager;
	}


	
	public DepartmentManager getDepartmentManagerByEmpNoAndFromDate(int empNo, LocalDate fromDate) throws DepartmentManagerNotFoundException {
	    DepartmentManager departmentManager = departmentManagerRespository.findByEmployee_EmpNoAndFromDate(empNo, fromDate);

	    if (departmentManager == null) {
	        throw new DepartmentManagerNotFoundException("No department manager found for empNo: " + empNo + " and fromDate: " + fromDate);
	    }

	    return departmentManager;
	}


}
