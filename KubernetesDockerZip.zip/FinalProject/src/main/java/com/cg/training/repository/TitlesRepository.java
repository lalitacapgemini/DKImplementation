package com.cg.training.repository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.training.entities.Titles;
import com.cg.training.entities.TitlesId;

import jakarta.transaction.Transactional;

@Repository
public interface TitlesRepository extends JpaRepository<Titles, TitlesId> {

    @Query("SELECT t FROM Titles t WHERE t.employee.empNo = :empNo AND t.fromDate = :fromDate AND t.title = :title")
    List<Titles> findByTypeId(@Param("empNo") int empNo, @Param("fromDate") LocalDate fromDate,
            @Param("title") String title);

 

    @Query("SELECT t FROM Titles t WHERE t.title = :title")
    List<Titles> findByTitles(@Param("title") String title);
    
    @Modifying
    @Transactional
    @Query("UPDATE Titles t SET t.title = :title WHERE t.employee.empNo = :emp_no")
    String updateTitleByEmpNo(@Param("title") String title, @Param("emp_no") int emp_no);


    @Query("SELECT t FROM Titles t WHERE t.fromDate = :fromDate")
    List<Titles> findByFromDate(@Param("fromDate") LocalDate fromDate);

 

    @Query("SELECT t FROM Titles t WHERE t.fromDate = :fromDate AND t.title = :title")
    List<Titles> findByFromDateAndTitle(@Param("fromDate") LocalDate fromDate, @Param("title") String title);

 

    @Query("SELECT t FROM Titles t WHERE t.employee.empNo = :empNo AND t.title = :title")
    List<Titles> findByEmpnoAndTitle(@Param("empNo") int empNo, @Param("title") String title);

 
    
    @Query("SELECT t FROM Titles t WHERE t.employee.empNo = :empNo AND t.fromDate = :fromDate")
    List<Titles> findByFromDateAnDempNo(@Param("empNo") int empNo, @Param("fromDate") LocalDate fromDate);    

    Titles findByEmployee_EmpNoAndFromDateAndTitle(int empNo, LocalDate fromDate, String title);
    
    Titles findByEmployee_EmpNo(int empNo);
    
    @Query("SELECT t FROM Titles t WHERE t.fromDate = :fromDate")
    Titles findByFromDate1(LocalDate fromDate);
    

      Titles findByTitle(String title);


	@Modifying
	@Query("DELETE FROM Titles t WHERE t.employee.empNo = :empNo AND t.fromDate = :fromDate AND t.title = :title")
	String deleteByEmployee_EmpNoAndFromDateAndTitle(
			@Param("empNo") int empNo, 
			@Param("fromDate") LocalDate fromDate,
			@Param("title") String title);

	@Modifying
	@Query("DELETE FROM Titles t WHERE t.employee.empNo = :empNo")
	String deleteByEmployee_EmpNo(@Param("empNo") int empNo);

	@Modifying
	@Query("DELETE FROM Titles t WHERE t.fromDate = :fromDate")
	String deleteByFromDate(@Param("fromDate") LocalDate fromDate);

	@Modifying
	@Query("DELETE FROM Titles t WHERE t.title = :title")
	String deletebyTitle(@Param("title") String title);
	
	@Modifying

    @Transactional

    @Query("UPDATE Titles t SET t.title = :newTitle WHERE t.employee.empNo = :empNo")

    void updateTitlesByEmpNo(@Param("newTitle") String newTitle, @Param("empNo") int empNo);

   

    

    @Modifying

    @Transactional

    @Query("UPDATE Titles t SET t.title = :newTitle WHERE t.fromDate = :fromDate")

    void updateTitleByFromDate(@Param("newTitle") String newTitle, @Param("fromDate") LocalDate fromDate);

    

    @Modifying

    @Transactional

    @Query("UPDATE Titles t SET t.title = :newTitle WHERE t.title = :oldTitle")

    void updateTitlesByTitle(@Param("newTitle") String newTitle, @Param("oldTitle") String oldTitle);

    

   

    

    @Modifying

    @Transactional

    @Query("UPDATE Titles t SET t.title = :newTitle WHERE t.employee.empNo = :empNo AND t.fromDate = :fromDate AND t.title = :oldTitle")

    void updateTitleByEmpNoAndFromDateAndTitle(

            @Param("newTitle") String newTitle,

            @Param("empNo") int empNo,

            @Param("fromDate") LocalDate fromDate,

            @Param("oldTitle") String oldTitle);







}
